package com.example

import android.content.Context
import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import com.example.data.local.AdminAnnouncementEntity
import com.example.data.local.AlHadithiDatabase
import com.example.data.local.SeedDataPart1
import com.example.data.remote.AUTHORIZED_DEVELOPER_EMAIL
import com.example.data.remote.QuranNetworkRepository
import com.example.media.AudioPlayerController
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

    @Test
    fun appName_andDeveloperEmailRestriction_matchAlHadithiSpec() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("الحديثي", appName)
        assertEquals("alnaziali0@gmail.com", AUTHORIZED_DEVELOPER_EMAIL)
    }

    @Test
    fun bundledQuran_isAcceptedOnlyWhenTheFullValidatedCorpusExists() = runBlocking {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val map = QuranNetworkRepository.ensureBundledQuranLoaded(context)
        if (map.isEmpty()) {
            // This source revision intentionally does not package the previous zero-byte placeholder.
            // Missing or incomplete Quran assets must never be advertised as a complete offline Mushaf.
            val assetExists = context.assets.list()?.contains("quran_uthmani_full.json") == true
            assertTrue("A missing local Mushaf must result in an empty bundled map", !assetExists)
        } else {
            assertEquals("The offline Mushaf must contain all 114 surahs", 114, map.size)
            assertEquals("The offline Mushaf must contain 6,236 ayahs", 6_236, map.values.sumOf { it.size })
        }
    }

    @Test
    fun roomSeedDatabase_populatesHusseiniOfflineAudio_Encyclopedia_AndAnnouncements() = runBlocking {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val db = Room.inMemoryDatabaseBuilder(context, AlHadithiDatabase::class.java)
            .allowMainThreadQueries()
            .build()
        try {
            val dao = db.dao()
            // Simulate a prior interrupted setup: the hadith table already has data,
            // while all other content tables are still empty.
            dao.insertHadiths(SeedDataPart1.authenticHadiths())
            AlHadithiDatabase.ensureSeeded(dao)

            assertTrue(dao.countCachedAyahs() > 0)
            assertTrue(dao.countHadiths() >= 10)
            assertTrue(dao.observeAllDuasAndZiyarat().first().isNotEmpty())
            assertTrue(dao.observeAllAdhkar().first().isNotEmpty())
            assertTrue(dao.observeAllBooks().first().isNotEmpty())
            assertTrue(dao.observeAllCourses().first().isNotEmpty())
            assertTrue(dao.observeAllWallpapers().first().size >= 3)

            // Resource names alone do not make an audio track available offline.
            val audioTracks = dao.observeAllAudioTracks().first()
            assertTrue(audioTracks.size >= 15)
            val tracksWithBundledNames = audioTracks.filter { it.offlineRawResName.isNotBlank() }
            assertTrue("Audio catalogue should retain the bundled-resource mapping", tracksWithBundledNames.size >= 8)
            AudioPlayerController.init(context)
            tracksWithBundledNames.forEach { track ->
                val resId = context.resources.getIdentifier(track.offlineRawResName, "raw", context.packageName)
                assertTrue("Declared raw resource '${track.offlineRawResName}' must exist", resId != 0)
                val firstRead = context.resources.openRawResource(resId).use { input ->
                    input.read(ByteArray(4_096))
                }
                if (firstRead <= 0) {
                    assertTrue(
                        "An empty MP3 resource must not be advertised as offline",
                        !AudioPlayerController.isTrackAvailableOffline("audio_${track.id}", track.offlineRawResName)
                    )
                }
            }

            // Seeding is safe to rerun: a second launch must not duplicate the starter catalogue.
            val beforeReseed = listOf(
                dao.countCachedAyahs(), dao.countHadiths(), dao.countDuasZiyarat(), dao.countAdhkar(),
                dao.countBooks(), dao.countCourses(), dao.countAudioTracks(), dao.countOccasions(),
                dao.countWallpapers(), dao.countContentSources()
            )
            AlHadithiDatabase.ensureSeeded(dao)
            val afterReseed = listOf(
                dao.countCachedAyahs(), dao.countHadiths(), dao.countDuasZiyarat(), dao.countAdhkar(),
                dao.countBooks(), dao.countCourses(), dao.countAudioTracks(), dao.countOccasions(),
                dao.countWallpapers(), dao.countContentSources()
            )
            assertEquals("Rerunning seed initialization must not duplicate content", beforeReseed, afterReseed)

            // Verify local announcements CRUD
            val adId = dao.insertAnnouncement(
                AdminAnnouncementEntity(
                    title = "مجلس عزاء مركزي",
                    body = "يقام المجلس في الصحن الحسيني الشريف الساعة الثامنة مساءً",
                    badgeLabel = "إعلان حسيني"
                )
            )
            assertEquals(1, dao.observeActiveAnnouncements().first().size)
            dao.deleteAnnouncementById(adId)
            assertEquals(0, dao.observeActiveAnnouncements().first().size)

            val occasions = dao.observeAllOccasions().first()
            assertTrue(occasions.isNotEmpty())
            val hasFirstNarration = occasions.any { it.hijriMonth == 5 && it.hijriDay == 13 }
            val hasSecondNarration = occasions.any { it.hijriMonth == 6 && it.hijriDay == 3 }
            assertTrue("Should include 13 Jumada I narration", hasFirstNarration)
            assertTrue("Should include 3 Jumada II narration", hasSecondNarration)
        } finally {
            db.close()
        }
    }
}
